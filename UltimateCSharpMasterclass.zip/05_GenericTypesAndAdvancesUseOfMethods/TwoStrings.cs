﻿
public class TwoStrings
{
    public TwoStrings(string string1, string string2)
    {
        String1 = string1;
        String2 = string2;
    }

    public string String1 { get; }
    public string String2 { get; }
}
