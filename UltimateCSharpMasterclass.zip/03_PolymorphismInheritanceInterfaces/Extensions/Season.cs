﻿namespace Polymorphism.Extensions
{
    public enum Season
    {
        Spring,
        Summer,
        Autumn,
        Winter
    }
}
