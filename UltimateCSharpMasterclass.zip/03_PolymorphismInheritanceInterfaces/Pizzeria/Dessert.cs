﻿namespace Pizzeria;

public abstract class Dessert { }


