﻿namespace Pizzeria;

public interface IBakeable
{
    string GetInstructions();
}


