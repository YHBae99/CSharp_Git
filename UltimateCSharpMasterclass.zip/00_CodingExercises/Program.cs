﻿//use to investigate the behavior of the classes from this project

Console.ReadKey();
