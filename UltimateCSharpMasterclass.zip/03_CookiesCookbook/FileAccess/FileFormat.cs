﻿namespace CookieCookbook.FileAccess;

public enum FileFormat
{
    Json,
    Txt
}
