﻿namespace CookieCookbook.Recipes.Ingredients;

public class Cinnamon : Spice
{
    public override int Id => 7;
    public override string Name => "Cinnamon";
}

