﻿namespace _6_LINQ.SampleData
{
    public enum PetType
    {
        Cat,
        Dog,
        Fish
    }
}
