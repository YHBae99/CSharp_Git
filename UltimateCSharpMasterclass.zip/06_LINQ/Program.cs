﻿//uncomment the method
//you are interested in to see how it behaves

//All.Run();
//Any.Run();
//Average.Run();
//Contains.Run();
//Count.Run();
//Distinct.Run();
//FirstLast.Run();
//Select.Run();
//Where.Run();

Console.WriteLine("Press any key to close.");
Console.ReadKey();
