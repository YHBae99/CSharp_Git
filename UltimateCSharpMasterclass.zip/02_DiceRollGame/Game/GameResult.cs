﻿namespace DiceRollGame.Game
{
    public enum GameResult
    {
        Victory,
        Loss
    }
}
