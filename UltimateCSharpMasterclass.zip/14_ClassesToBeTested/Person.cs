﻿namespace _14_ClassesToBeTested;

public record Person(int Id, string FirstName, string LastName);