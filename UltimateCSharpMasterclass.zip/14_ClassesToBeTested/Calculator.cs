﻿public static class Calculator
{
    public static int Sum(int a, int b) => a + b;
}
