# UltimateCSharpMasterclass

Hello! 

My name is Krystyna and welcome to my GitHub.

This repository is part of my  **"Ultimate C# Masterclass"** course, which you can find under this link: https://www.udemy.com/course/ultimate-csharp-masterclass/?referralCode=43763BBDA97D7D0B571A

## FAQ:

### Q1: How do I download the files?
A: If you're not familiar with Git and just want to download the entire solution, click the green button saying "Code", and then select the "Download ZIP". If you know some Git, just clone this repository to your machine.

### Q2: How do I open those files?
A: Simply open the UltimateCSharpMasterclass.sln file with Visual Studio. 

### Q3: What are the projects in this solution?
A: Projects in this solution correspond to sections in the course. There are separate projects for assignments, and sometimes also helper projects for special use cases. Project "00_Exercises" contains the solutions of in-browser exercises you can solve within Udemy.

### Q4: How do I run a particular project?
A: Right-click on it in Visual Studio, select "Set as startup project" and click "Run" in the top menu of Visual Studio.
